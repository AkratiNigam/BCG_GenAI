import  streamlit as st
import pandas as pd

def input_data():
    data = pd.read_csv("BCG TASK 1.csv")
    data = data.sort_values(['Company','Year'],ascending=True).groupby('Company').head()
    return data

def revenue_info(data):
    data_revenue = pd.DataFrame(columns=['Company','Year','Total Revenue','% of Revenue Growth'])
    data_revenue['Company'] = data['Company']
    data_revenue['Year'] = data['Year']
    data_revenue['Total Revenue'] = data['Total Revenue']
    data_revenue['% of Revenue Growth'] = data.groupby(['Company'])['Total Revenue'].pct_change() * 100
    return data_revenue

def assets_info(data):
    data_assets = pd.DataFrame(columns=['Company','Year','Total Assets','% of Total Assets Growth'])
    data_assets['Company'] = data['Company']
    data_assets['Year'] = data['Year']
    data_assets['Total Assets'] = data['Total Assets']
    data_assets['% of Assets Growth'] = data.groupby(['Company'])['Total Assets'].pct_change() * 100
    return data_assets

def income_info(data):
    data_income = pd.DataFrame(columns=['Company','Year','Net Income','% of Net Income Growth'])
    data_income['Company'] = data['Company']
    data_income['Year'] = data['Year']
    data_income['Net Income'] = data['Net Income']
    data_income['% of Net Income Growth'] = data.groupby(['Company'])['Net Income'].pct_change() * 100
    return data_income

def liability_info(data):
    data_liability = pd.DataFrame(columns=['Company','Year','Total Liabilities','% of Liabilities Growth'])
    data_liability['Company'] = data['Company']
    data_liability['Year'] = data['Year']
    data_liability['Total Liabilities'] = data['Total Liabilities']
    data_liability['% of Liabilities Growth'] = data.groupby(['Company'])['Total Liabilities'].pct_change() * 100
    return data_liability

def cashflow_info(data):
    data_cashflow = pd.DataFrame(columns=['Company','Year','Cashflow','% of Cashflow Growth'])
    data_cashflow['Company'] = data['Company']
    data_cashflow['Year'] = data['Year']
    data_cashflow['Cash Flow'] = data['Cash Flow']
    data_cashflow['% of Cashflow Growth'] = data.groupby(['Company'])['Cash Flow'].pct_change() * 100
    return data_cashflow

def main():
    data = input_data()
    st.title("Financial ChatBot")
    chatbox = st.container(height=300, border=True)
    prompt = chatbox.chat_input("How can i help you", key="chat-input")
    if prompt:
        if prompt.lower().find("revenue of apple in 2023") != -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][7]
            chatbox.write(f"Total Revenue of Apple in the Year 2022 was ${(format (value, ',d'))}")
        if prompt.lower().find("revenue of apple in 2022") != -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][6]
            chatbox.write(f"Total Revenue of Apple in the Year 2022 was ${(format (value, ',d'))}")
        if prompt.lower().find("revenue of apple") != -1 and prompt.lower().find("2023") == -1 and prompt.lower().find("2022") == -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][8]
            chatbox.write(f"Total Revenue of Apple in the Year 2024 was ${(format (value, ',d'))}")

        if prompt.lower().find("revenue of microsoft in 2023") != -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][1]
            chatbox.write(f"Total Revenue of Microsoft in the Year 2022 was ${(format (value, ',d'))}")
        if prompt.lower().find("revenue of apple in 2022") != -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][2]
            chatbox.write(f"Total Revenue of Microsoft in the Year 2022 was ${(format (value, ',d'))}")
        if prompt.lower().find("revenue of microsoft") != -1 and prompt.lower().find("2023") == -1 and prompt.lower().find("2022") == -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][0]
            chatbox.write(f"Total Revenue of Microsoft in the Year 2024 was ${(format (value, ',d'))}")

        if prompt.lower().find("revenue of tesla in 2023") != -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][4]
            chatbox.write(f"Total Revenue of Tesla in the Year 2022 was ${(format (value, ',d'))}")
        if prompt.lower().find("revenue of apple in 2022") != -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][5]
            chatbox.write(f"Total Revenue of Tesla in the Year 2022 was ${(format (value, ',d'))}")
        if prompt.lower().find("revenue of tesla") != -1 and prompt.lower().find("2023") == -1 and prompt.lower().find("2022") == -1:
            data_revenue = revenue_info(data)
            value = data_revenue['Total Revenue'][3]
            chatbox.write(f"Total Revenue of Tesla in the Year 2024 was ${(format (value, ',d'))}")

        if prompt.lower().find("income changed for") != -1 or prompt.lower().find("change in income for") != -1:
            company_name = prompt.split('for')[1].strip().lower()
            if company_name == 'apple':
                index = 6
            if company_name == 'microsoft':
                index = 0
            if company_name == 'tesla':
                index = 3
            data_income = income_info(data)
            change = data_income['% of Net Income Growth'][index]
            print(data_income['% of Net Income Growth'])
            if change < 0:
                chatbox.write(f"The revenue has decreased for {company_name.capitalize()} in the year 2024 by about {round(change,2)}%")
            else:
                chatbox.write(f"The revenue has increased for {company_name.capitalize()} in the year 2024 by about {round(change,2)}%")


if __name__ == "__main__":
    main()

